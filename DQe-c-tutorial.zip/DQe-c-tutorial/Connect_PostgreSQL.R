#########################################################
############################################################################
####### This script connects your R to your PostgreSQL database.  ##


# read username and password
source("keys.R")

# set up connection
drv <- dbDriver("PostgreSQL")
conn <- dbConnect(drv,
                 dbname = "cdm",
                 host = "localhost",
                 port = 5432,
                 user = usrnm,
                 password = pss
                 )
rm(pss)

#######
######## If you don't know your data base name, host, or port, contact your server admin.
#######