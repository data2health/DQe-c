#Connect_RedshiftServer.R
library(RJDBC)

# download Amazon Redshift JDBC driver if the file doesn't exist
if(!file.exists('RedshiftJDBC41-1.1.9.1009.jar')) {
  download.file('http://s3.amazonaws.com/redshift-downloads/drivers/RedshiftJDBC41-1.1.9.1009.jar','RedshiftJDBC41-1.1.9.1009.jar')
}

# read username and password
source("keys.R")

# set up connection
path01 <- getwd()
drv <- JDBC("com.amazon.redshift.jdbc41.Driver", paste0(path01,"/RedshiftJDBC41-1.1.9.1009.jar", identifier.quote=""))

# connect to Amazon Redshift
# url <- "<JDBCURL>:<PORT>/<DBNAME>
url <- "jdbc:redshift://ohdsitutorialtest2-ohdsielas-redshiftclustermulti-1sizz9gq0e4uq.cc8ltappgfjt.us-east-1.redshift.amazonaws.com:5439/mycdm?ssl=true"
conn <- dbConnect(drv, url, usrnm, pss)

rm(pss)

#######
######## If you don't know your data base name and address, contact your server admin.
#######